# VUST RedCross Link — staff activation checklist

The server-side staff allowlist is already configured for:

- `nuwaherezalevi2@gmail.com` — administrator
- `vust2026urcs@gmail.com` — reviewer

**The allowlist does not create Supabase Auth accounts or send invitations.** Complete this one-time step in the Supabase Dashboard:

1. Open project `tmfwghzvhgkxpzrvcbdm`.
2. Go to **Authentication → Users**.
3. Invite each email address listed above. Do not enable public sign-ups.
4. Each staff member must accept the invitation and verify the email address.
5. Check that the project's email/OTP template supports sending a one-time code (the staff portal uses the email OTP flow).
6. Open `/staff.html` on the deployed website, request a code, verify it, and confirm the three review categories load.
7. Test status changes using a test record only. Do not use real applicant records for initial testing.

Staff API requests validate the Supabase Auth access token, require a verified email, and check the private allowlist on every request. The public site does not receive database service credentials.

If a staff member leaves, disable their Auth user/session and set their allowlist `active` value to `false` through an authorized administrative database session. Do not share passwords or OTP codes.
