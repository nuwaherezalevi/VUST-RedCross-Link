# VUST RedCross Link Website

A responsive, static multi-page website concept developed by **NL DIGITAL LABs CENTER**.

## Pages
- `index.html` — Homepage
- `about.html` — Background, vision, mission, values and principles
- `programmes.html` — Programme descriptions based on the supplied Constitution
- `get-involved.html` — Membership, volunteering, training and partnerships
- `news.html` — News and activity publishing framework
- `resources.html` — Constitution and organizational resources
- `contact.html` — Contact details and Supabase-backed enquiry form

## Run locally
1. Extract the ZIP file.
2. Open the `vust-redcross-link-website` folder.
3. Double-click `index.html`, or use a local development server such as VS Code Live Server.
4. Navigate using the menu.

No build tools or package installation are required.

## Customize
- Edit page text in the relevant `.html` file.
- Change colors, fonts, spacing and layout in `assets/styles.css`.
- Update menu behavior and contact form handoff in `assets/script.js`.
- Replace the remote Unsplash images in CSS with approved organization photographs.
- Add real event reports, testimonials, impact figures and leadership profiles only after verification and approval.

## Contact details included
- Email: vust2026urcs@gmail.com
- Phone: +256 768 249 632
- Alternative contact: +256 394 321 593

## Important launch checks
1. The supplied Constitution is titled **Draft 1, 2026** and has blank adoption and approval fields. Confirm the current approved constitutional version and institutional recognition status before publishing final claims.
2. The Red Cross emblem is protected. The current design uses an abstract letterform mark, not the emblem. Use the emblem, uniforms or official marks only with appropriate authorization and in line with Uganda Red Cross Society policy.
3. Membership, volunteer and contact forms submit to the separate VUST RedCross Link Supabase project using a browser-safe publishable key. Row Level Security permits public inserts only with consent and default pending/new statuses; public users cannot read, update or delete private submissions. Publish a privacy notice, add abuse/rate-limit protection, and define authorized staff access before production use.
4. Add approved photos with informed consent, safeguarding review and image rights clearance.
5. Add verified testimonials, impact data, office hours, social media links and actual activity calendar when available.
6. Review accessibility, privacy, safeguarding, security and mobile behavior before launch.

## Design system
- Red accent: `#A51F32`
- Deep red: `#7F1728`
- Navy: `#142B3B`
- Main text: `#202B33`
- Muted text: `#64727C`
- Light background: `#F5F7F8`
- Fonts: Manrope for headings, DM Sans for body (Google Fonts; local fallback included)
- Main content max width: 1160px
- Card radius: 16px; buttons: 9px radius
- Responsive breakpoints: 1050px, 800px and 520px

## Homepage conversion hierarchy
Hero CTA → programme discovery → benefits → organizational principles → FAQs → get-involved CTA → contact.

## Audit checklist before launch
- Test all links and contact actions on Android, iOS and desktop.
- Confirm current membership process and who monitors enquiries.
- Add a real privacy notice and safeguarding reporting instructions.
- Verify image permissions and alternative text.
- Add page titles, metadata, favicon and social sharing image.
- Configure analytics only with appropriate privacy notice/consent.
- Connect a domain and HTTPS hosting.

## Supabase integration
- Project: `vust-redcross-link` (`tmfwghzvhgkxpzrvcbdm`).
- Browser configuration: `assets/supabase-config.js` contains only the project's publishable key.
- Forms submit with `Prefer: return=minimal`; they do not request or expose private submission rows.
- `news.html` reads only published articles visible under the `news_articles` Row Level Security policy.
- Do not add a service-role or secret key to any browser file.
- Configure staff authentication and least-privilege review access separately before creating an admin dashboard.


## Privacy, abuse protection and staff review

- `privacy.html` explains collected information, purposes, access, hosting providers, rights and the intended 12-month post-closure retention review. It is approved for use by the Link representative for this project; university/URCS records requirements still take precedence.
- Public forms now call the `vust-redcross-api` Supabase Edge Function rather than inserting directly through the Data API. The function validates fields server-side, enforces per-IP and per-email request limits, checks the website origin, and silently drops honeypot submissions.
- `staff.html` is a restricted staff review portal using email one-time codes. Staff must first be invited as Supabase Auth users and must also be on the private allowlist. The RLS-protected, server-only allowlist currently contains `nuwaherezalevi2@gmail.com` (administrator) and `vust2026urcs@gmail.com` (reviewer).
- Staff API checks verified Supabase Auth identity and the private allowlist on every request. Public users cannot list or update submissions.
- `closed_at` records when a review is closed. The stated retention target is 12 months after closure, subject to institutional policy. Automatic deletion is intentionally not enabled pending confirmation of the university/URCS records schedule.
- Cloudflare Turnstile has not been added; it can be layered on later.

### One-time staff activation required

In Supabase Dashboard for project `tmfwghzvhgkxpzrvcbdm`, open Authentication → Users and invite the two allowlisted addresses. They must accept the invitation and verify their email before the staff portal will grant access. Do not enable public sign-ups.


The Supabase Edge Function `vust-redcross-api` is deployed to project `tmfwghzvhgkxpzrvcbdm` (active version 3). The Netlify website files in this package have **not** been deployed to production. See `STAFF-SETUP.md` for the remaining staff invitation step.
