document.addEventListener("DOMContentLoaded", () => {
  const year = document.getElementById("year");
  if (year) year.textContent = new Date().getFullYear();

  const toggle = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".nav");
  if (toggle && nav) {
    toggle.addEventListener("click", () => {
      const open = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(open));
      toggle.setAttribute("aria-label", open ? "Close navigation" : "Open navigation");
      toggle.textContent = open ? "✕" : "☰";
    });
  }

  const config = window.VUST_SUPABASE_CONFIG;
  const hasSupabaseConfig = Boolean(config && config.url && config.publishableKey);

  async function insertPublicRow(table, payload, website = "") {
    if (!hasSupabaseConfig) throw new Error("The form service is not configured. Please contact the Link directly.");
    const response = await fetch(`${config.url}/functions/v1/vust-redcross-api`, {
      method: "POST",
      headers: {
        apikey: config.publishableKey,
        Authorization: `Bearer ${config.publishableKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ mode: "submit", table, payload, website })
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok || !result.ok) {
      throw new Error(result.error || "We could not submit your details. Please try again later.");
    }
  }

  function valuesFor(form, name) {
    return [...form.querySelectorAll(`input[name="${name}"]:checked`)].map(input => input.value);
  }

  function bindSubmission(formId, noteId, table, makePayload, successMessage) {
    const form = document.getElementById(formId);
    const note = document.getElementById(noteId);
    if (!form || !note) return;

    form.addEventListener("submit", async event => {
      event.preventDefault();
      if (!form.reportValidity()) return;
      const data = new FormData(form);
      if (String(data.get("website") || "").trim()) return;

      const submitButton = form.querySelector('button[type="submit"]');
      const originalLabel = submitButton ? submitButton.textContent : "";
      if (submitButton) {
        submitButton.disabled = true;
        submitButton.textContent = "Submitting…";
      }
      note.textContent = "Submitting securely…";

      try {
        await insertPublicRow(table, makePayload(data, form), String(data.get("website") || ""));
        form.reset();
        note.textContent = successMessage;
      } catch (error) {
        note.textContent = error.message || "Submission failed. Please try again.";
      } finally {
        if (submitButton) {
          submitButton.disabled = false;
          submitButton.textContent = originalLabel;
        }
      }
    });
  }

  const contactForm = document.getElementById("contactForm");
  if (contactForm) {
    const requestedSubject = new URLSearchParams(window.location.search).get("subject");
    const topicSelect = document.getElementById("topic");
    if (requestedSubject && topicSelect) {
      const firstWord = requestedSubject.split(/\\s+/)[0].toLowerCase();
      const matchingOption = [...topicSelect.options].find(option =>
        option.text.toLowerCase().includes(firstWord)
      );
      if (matchingOption) topicSelect.value = matchingOption.value;
    }
  }

  bindSubmission("membershipForm", "membershipNote", "membership_applications", (data, form) => ({
    full_name: String(data.get("full_name") || "").trim(),
    email: String(data.get("email") || "").trim(),
    phone: String(data.get("phone") || "").trim(),
    student_id: String(data.get("student_id") || "").trim() || null,
    faculty_or_department: String(data.get("faculty_or_department") || "").trim() || null,
    year_of_study: String(data.get("year_of_study") || "").trim() || null,
    areas_of_interest: valuesFor(form, "areas_of_interest"),
    motivation: String(data.get("motivation") || "").trim() || null,
    consent: data.get("consent") === "true"
  }), "Thank you. Your membership application has been received and is pending review.");

  bindSubmission("volunteerForm", "volunteerNote", "volunteer_registrations", (data, form) => ({
    full_name: String(data.get("full_name") || "").trim(),
    email: String(data.get("email") || "").trim(),
    phone: String(data.get("phone") || "").trim(),
    skills: String(data.get("skills") || "").trim() || null,
    availability: String(data.get("availability") || "").trim() || null,
    areas_of_interest: valuesFor(form, "areas_of_interest"),
    consent: data.get("consent") === "true"
  }), "Thank you. Your volunteer registration has been received and is pending review.");

  bindSubmission("contactForm", "formNote", "contact_messages", data => ({
    full_name: String(data.get("name") || "").trim(),
    email: String(data.get("email") || "").trim(),
    subject: String(data.get("topic") || "").trim(),
    message: String(data.get("message") || "").trim(),
    consent: data.get("consent") === "true"
  }), "Thank you. Your enquiry has been received. The Link team can follow up using the email address you provided.");

  const newsTarget = document.getElementById("publishedNews");
  if (newsTarget && hasSupabaseConfig) {
    const fallback = document.getElementById("newsFallback");
    const newsQuery = new URLSearchParams({
      select: "title,summary,body,category,author_name,published_at",
      is_published: "eq.true",
      published_at: `lte.${new Date().toISOString()}`,
      order: "published_at.desc",
      limit: "12"
    });
    fetch(`${config.url}/rest/v1/news_articles?${newsQuery.toString()}`, {
      headers: {
        apikey: config.publishableKey,
        Authorization: `Bearer ${config.publishableKey}`,
        Accept: "application/json",
        "Accept-Profile": "public"
      }
    }).then(response => {
      if (!response.ok) throw new Error("News could not be loaded.");
      return response.json();
    }).then(articles => {
      if (!Array.isArray(articles) || articles.length === 0) return;
      newsTarget.replaceChildren();
      articles.forEach(article => {
        const card = document.createElement("article");
        card.className = "card";
        const label = document.createElement("div");
        label.className = "news-label";
        label.textContent = article.category || "UPDATE";
        const heading = document.createElement("h3");
        heading.textContent = article.title || "Community update";
        const summary = document.createElement("p");
        summary.textContent = article.summary || "";
        card.append(label, heading, summary);
        if (article.published_at) {
          const date = document.createElement("p");
          date.className = "form-note";
          date.textContent = new Date(article.published_at).toLocaleDateString();
          card.append(date);
        }
        newsTarget.append(card);
      });
      if (fallback) fallback.hidden = true;
    }).catch(() => {
      // Keep the approved static editorial placeholders visible if the feed is unavailable.
    });
  }
});