// Public client configuration for the VUST RedCross Link Supabase project.
// This publishable key is intended for browser use. Never place a server-only key here.
window.VUST_SUPABASE_CONFIG = Object.freeze({
  url: "https://tmfwghzvhgkxpzrvcbdm.supabase.co",
  publishableKey: "sb_publishable_lGkbkw8m6SF0aTNAPP7sCA_JRueRXwS"
});
