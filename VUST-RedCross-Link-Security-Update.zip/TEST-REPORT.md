# Security implementation test report

Date: 7 November 2026
Project: VUST RedCross Link website / Supabase project `tmfwghzvhgkxpzrvcbdm`

## Implemented
- Added `privacy.html` and linked it from public page footers and application/enquiry consent text.
- Updated public membership, volunteer and contact submissions to call the server-side Supabase Edge Function `vust-redcross-api`.
- Edge Function version 3 is active. It validates allowed submission types and fields, enforces request size, checks website origin, applies a 10-submission / 10-minute IP bucket and 3-submission / hour email bucket, and silently drops honeypot submissions.
- Added an RLS-enabled staff allowlist for `nuwaherezalevi2@gmail.com` (administrator) and `vust2026urcs@gmail.com` (reviewer). Client roles have no table privileges; the Edge Function checks verified Supabase Auth identity and allowlist membership for every staff operation.
- Added `staff.html` for email OTP login, listing up to 100 latest submissions per category and updating review status.
- Added `closed_at` fields to membership, volunteer and contact records. The intended review-for-deletion point is 12 months after closure, subject to institutional records policy.

## Verification performed
- All 9 HTML pages parsed successfully.
- All local asset links checked; no missing references.
- `node --check` passed for `assets/script.js` and `assets/staff.js`.
- Supabase Edge Function reports ACTIVE, version 3.
- Supabase security advisor returned no lints after the final database changes.
- Database privilege checks confirmed `anon` and `authenticated` cannot read the staff allowlist; `service_role` can. Public clients cannot execute the rate-limit function; `service_role` can.
- Rate-limit SQL test returned `true`, `true`, then `false` for a two-request limit.
- No applicant records were created by these tests.

## Remaining before the website is ready for use
- Invite both allowlisted staff emails under Supabase Dashboard → Authentication → Users. The allowlist does not itself create Auth users or send invitations. Keep public sign-ups disabled. Follow `STAFF-SETUP.md`.
- Test staff email OTP delivery and the staff portal after the invitation emails are accepted.
- Complete a real browser-based public form test and visual review on a Netlify Deploy Preview. These browser tests have not yet been performed.
- Cloudflare Turnstile is not installed; the user selected server-side validation and rate limiting first.
- Automatic deletion after 12 months is not enabled. The system records `closed_at`; deletion scheduling should wait for the institution's formal records-retention rules.
- Netlify production website has not been deployed or modified. The live website remains unchanged until explicit approval.
