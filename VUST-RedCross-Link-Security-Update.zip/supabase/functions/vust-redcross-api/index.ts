import { createClient } from "npm:@supabase/supabase-js@2";

const PROJECT_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? Deno.env.get("SUPABASE_SECRET_KEY")!;
const PUBLIC_KEY = Deno.env.get("SUPABASE_ANON_KEY") ?? Deno.env.get("SUPABASE_PUBLISHABLE_KEY") ?? "";
const allowedOrigins = new Set([
  "https://vustredcross.netlify.app",
  "http://localhost:3000",
  "http://127.0.0.1:5500"
]);
const corsHeaders = {
  "Access-Control-Allow-Headers": "authorization, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Vary": "Origin"
};
const service = createClient(PROJECT_URL, SERVICE_KEY, { auth: { persistSession: false, autoRefreshToken: false } });
const authClient = createClient(PROJECT_URL, PUBLIC_KEY || SERVICE_KEY, { auth: { persistSession: false, autoRefreshToken: false } });

const json = (data: unknown, status = 200, origin = "") => new Response(JSON.stringify(data), {
  status,
  headers: { ...corsHeaders, ...(origin ? { "Access-Control-Allow-Origin": origin } : {}), "Content-Type": "application/json", "Cache-Control": "no-store" }
});
const clean = (v: unknown, max: number) => typeof v === "string" ? v.trim().slice(0, max) : "";
const validEmail = (v: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) && v.length <= 254;
const sha = async (value: string) => {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return [...new Uint8Array(digest)].map(x => x.toString(16).padStart(2, "0")).join("");
};
async function limited(bucket: string, max: number, seconds: number) {
  const { data, error } = await service.rpc("consume_vust_rate_limit", {
    p_bucket: bucket, p_limit: max, p_window_seconds: seconds
  });
  if (error) throw error;
  return data === true;
}
function validatePayload(table: string, p: Record<string, unknown>) {
  const full_name = clean(p.full_name, 120);
  const email = clean(p.email, 254).toLowerCase();
  const phone = clean(p.phone, 30);
  const consent = p.consent === true;
  const areas = Array.isArray(p.areas_of_interest) ? p.areas_of_interest.slice(0, 10).map(x => clean(x, 100)).filter(Boolean) : [];
  if (full_name.length < 2 || !validEmail(email) || phone.length < 7 || !consent) throw new Error("Please check the required fields and consent.");
  if (table === "membership_applications") return {
    full_name, email, phone, consent,
    student_id: clean(p.student_id, 50) || null,
    faculty_or_department: clean(p.faculty_or_department, 120) || null,
    year_of_study: clean(p.year_of_study, 40) || null,
    areas_of_interest: areas,
    motivation: clean(p.motivation, 3000) || null
  };
  if (table === "volunteer_registrations") return {
    full_name, email, phone, consent,
    skills: clean(p.skills, 2000) || null,
    availability: clean(p.availability, 1000) || null,
    areas_of_interest: areas
  };
  if (table === "contact_messages") {
    const subject = clean(p.subject, 160);
    const message = clean(p.message, 5000);
    if (subject.length < 2 || message.length < 5) throw new Error("Please provide an enquiry subject and message.");
    return { full_name, email, subject, message, consent };
  }
  throw new Error("Unsupported submission type.");
}

async function handlePublicSubmit(body: Record<string, unknown>, req: Request) {
  const table = clean(body.table, 40);
  const forwarded = req.headers.get("cf-connecting-ip") || req.headers.get("x-nf-client-connection-ip") || (req.headers.get("x-forwarded-for") || "").split(",")[0].trim() || "unknown";
  const ipHash = await sha(forwarded);
  if (!(await limited("public:ip:" + ipHash, 10, 600))) return { error: "Too many submissions. Please wait and try again later.", status: 429 };
  if (clean(body.website, 200)) return { ok: true }; // honeypot: silently discard bots
  const payload = validatePayload(table, body.payload && typeof body.payload === "object" ? body.payload as Record<string, unknown> : {});
  if (!(await limited("public:email:" + await sha((payload as {email:string}).email), 3, 3600))) return { error: "This email has reached the submission limit. Please try again later.", status: 429 };
  const { error } = await service.from(table).insert(payload);
  if (error) {
    console.error("submission_insert_failed", error.code);
    return { error: "We could not submit your details. Please try again later.", status: 400 };
  }
  return { ok: true };
}

async function handleStaff(body: Record<string, unknown>, req: Request) {
  const auth = req.headers.get("Authorization") || "";
  const token = auth.replace(/^Bearer\s+/i, "");
  if (!token || token === PUBLIC_KEY) return { error: "Staff sign-in is required.", status: 401 };
  const { data: userData, error: userError } = await authClient.auth.getUser(token);
  const user = userData?.user;
  if (userError || !user?.email || !user.email_confirmed_at) return { error: "Your staff session is invalid or your email is not verified.", status: 401 };
  const email = user.email.toLowerCase();
  const { data: staff, error: staffError } = await service.from("vust_staff_allowlist")
    .select("email,role,active").eq("email", email).eq("active", true).maybeSingle();
  if (staffError || !staff) return { error: "This account is not authorized for staff review.", status: 403 };
  const action = clean(body.action, 20);
  const table = clean(body.table, 40);
  const allowedTables = ["membership_applications", "volunteer_registrations", "contact_messages"];
  if (!allowedTables.includes(table)) return { error: "Unsupported review area.", status: 400 };

  if (action === "list") {
    const { data, error } = await service.from(table).select("*").order("created_at", { ascending: false }).limit(100);
    if (error) return { error: "Submissions could not be loaded.", status: 500 };
    return { ok: true, submissions: data ?? [], staff: { email, role: staff.role } };
  }
  if (action === "update") {
    const id = clean(body.id, 50);
    const status = clean(body.status, 30);
    const allowed = table === "contact_messages" ? ["new", "in_progress", "resolved", "spam"] :
      ["pending", "reviewed", "accepted", "declined"];
    if (!id || !allowed.includes(status)) return { error: "Invalid record or status.", status: 400 };
    const closed = table === "contact_messages" ? ["resolved", "spam"].includes(status) : ["accepted", "declined"].includes(status);
    const { data, error } = await service.from(table).update({ status, closed_at: closed ? new Date().toISOString() : null })
      .eq("id", id).select("id,status,closed_at").maybeSingle();
    if (error || !data) return { error: "The record could not be updated.", status: 400 };
    return { ok: true, record: data };
  }
  return { error: "Unsupported staff action.", status: 400 };
}

Deno.serve(async (req: Request) => {
  const origin = req.headers.get("Origin") || "";
  if (req.method === "OPTIONS") return new Response("ok", { headers: { ...corsHeaders, ...(allowedOrigins.has(origin) ? { "Access-Control-Allow-Origin": origin } : {}) } });
  if (req.method !== "POST") return json({ error: "Method not allowed." }, 405, allowedOrigins.has(origin) ? origin : "");
  if (!allowedOrigins.has(origin)) return json({ error: "Origin not allowed." }, 403);
  try {
    const rawBody = await req.text();
    if (new TextEncoder().encode(rawBody).byteLength > 12000) return json({ error: "Request is too large." }, 413, origin);
    const body = JSON.parse(rawBody);
    if (!body || typeof body !== "object") return json({ error: "Invalid request." }, 400, origin);
    const mode = clean(body.mode, 20);
    const result = mode === "submit" ? await handlePublicSubmit(body, req) : mode === "staff" ? await handleStaff(body, req) : { error: "Unsupported request.", status: 400 };
    const status = Number((result as {status?:number}).status || 200);
    return json(result, status, origin);
  } catch (error) {
    console.error("vust-api-error", error instanceof Error ? error.message : "unknown");
    return json({ error: "The request could not be processed. Please check the details and try again." }, 400, origin);
  }
});
