-- VUST RedCross Link: private rate limiting, staff access allowlist, and closure dates.
drop function if exists private.consume_rate_limit(text, integer, integer);
drop table if exists private.staff_allowlist;
create schema if not exists private;
revoke all on schema private from public, anon, authenticated;
grant usage on schema private to service_role;

create table if not exists private.request_rate_limits (
  bucket text primary key,
  window_started_at timestamptz not null,
  request_count integer not null check (request_count >= 0)
);
alter table private.request_rate_limits enable row level security;
revoke all on private.request_rate_limits from public, anon, authenticated;
grant select, insert, update, delete on private.request_rate_limits to service_role;

create table if not exists public.vust_staff_allowlist (
  email text primary key check (email = lower(trim(email))),
  role text not null default 'reviewer' check (role in ('administrator','reviewer')),
  active boolean not null default true,
  created_at timestamptz not null default now()
);
alter table public.vust_staff_allowlist enable row level security;
revoke all on public.vust_staff_allowlist from public, anon, authenticated;
grant select, insert, update, delete on public.vust_staff_allowlist to service_role;
create policy "Deny client access to staff allowlist"
on public.vust_staff_allowlist for all to anon, authenticated using (false) with check (false);

insert into public.vust_staff_allowlist(email, role, active) values
  ('nuwaherezalevi2@gmail.com','administrator',true),
  ('vust2026urcs@gmail.com','reviewer',true)
on conflict (email) do update set role = excluded.role, active = excluded.active;

create or replace function public.consume_vust_rate_limit(p_bucket text, p_limit integer, p_window_seconds integer)
returns boolean
language plpgsql
security definer
set search_path = pg_catalog, private
as $$
declare v_count integer;
begin
  if p_limit < 1 or p_window_seconds < 1 or length(p_bucket) > 200 then return false; end if;
  insert into private.request_rate_limits(bucket, window_started_at, request_count)
  values (p_bucket, clock_timestamp(), 1)
  on conflict (bucket) do update
    set window_started_at = case
          when private.request_rate_limits.window_started_at <= clock_timestamp() - make_interval(secs => p_window_seconds)
          then clock_timestamp() else private.request_rate_limits.window_started_at end,
        request_count = case
          when private.request_rate_limits.window_started_at <= clock_timestamp() - make_interval(secs => p_window_seconds)
          then 1 else private.request_rate_limits.request_count + 1 end
  returning request_count into v_count;
  return v_count <= p_limit;
end;
$$;
revoke all on function public.consume_vust_rate_limit(text, integer, integer) from public, anon, authenticated;
grant execute on function public.consume_vust_rate_limit(text, integer, integer) to service_role;

alter table public.membership_applications add column if not exists closed_at timestamptz;
alter table public.volunteer_registrations add column if not exists closed_at timestamptz;
alter table public.contact_messages add column if not exists closed_at timestamptz;
comment on column public.membership_applications.closed_at is 'Set when the application review is closed; retention review is due 12 months after this timestamp.';
comment on column public.volunteer_registrations.closed_at is 'Set when the volunteer registration review is closed; retention review is due 12 months after this timestamp.';
comment on column public.contact_messages.closed_at is 'Set when the enquiry is resolved or classified as spam; retention review is due 12 months after this timestamp.';
comment on table public.vust_staff_allowlist is 'RLS-enabled staff allowlist; all access revoked from public client roles and mediated by the server-side Edge Function.';
